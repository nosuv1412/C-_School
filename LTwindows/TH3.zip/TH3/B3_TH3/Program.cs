﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B3_TH3
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
